package com.demo.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.webkit.WebView;

import com.google.android.material.shape.RoundedCornerTreatment;
import com.google.android.material.shape.ShapePathModel;

public class MainActivity extends AppCompatActivity {

    WebView mWebview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        ShapePathModel leftShapePathModel = new ShapePathModel();
//        leftShapePathModel.setTopLeftCorner(new RoundedCornerTreatment(10));
//        leftShapePathModel.setTopRightCorner(new RoundedCornerTreatment(10));
//        MaterialShapeDrawable bg = new MaterialShapeDrawable(leftShapePathModel);
//        container.setBackground(bg);
//
//
//        container.invalidate();

        CardView mCl;
        mWebview = findViewById(R.id.webview);
        mWebview.loadUrl("https://www.douyin.com/");
    }
}
