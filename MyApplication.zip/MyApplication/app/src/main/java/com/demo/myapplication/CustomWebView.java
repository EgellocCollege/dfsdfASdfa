package com.demo.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Region;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.webkit.WebView;

public class CustomWebView extends WebView
{
    private final static float CORNER_RADIUS = 10.0f;

    private Bitmap maskBitmap;
    private Paint paint, maskPaint;
    private float cornerRadius;

    public CustomWebView(Context context) {
        super(context);
        init(context, null, 0);
        initView(context);
    }

    public CustomWebView(Context context, AttributeSet   attrs) {
        super(context, attrs);
        init(context, attrs, 0);
        initView(context);
    }

    public CustomWebView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context, attrs, defStyle);
        initView(context);
    }

    private void init(Context context, AttributeSet attrs, int defStyle) {
        DisplayMetrics   metrics = context.getResources().getDisplayMetrics();
        cornerRadius =   TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, CORNER_RADIUS, metrics);

        paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        maskPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        maskPaint.setXfermode(new PorterDuffXfermode(  PorterDuff.Mode.CLEAR));

        setWillNotDraw(false);
    }

    @Override
    public void onDraw(Canvas canvas) {
        int x = this.getScrollX();
        int y = this.getScrollY();
        Path path = new Path();
        path.addRoundRect(new RectF(10, 10,   getMeasuredWidth(),   getMeasuredHeight()), 16,16, Path.Direction.CW);        // 使用半角的方式，性能比较好
//        canvas.clipPath(path);
        canvas.clipPath(path, Region.Op.INTERSECT);


//        Path clipPath = new Path();
//        clipPath.addRoundRect(new RectF(10, 10,   getMeasuredWidth(),   getMeasuredHeight()), 26,16, Path.Direction.CW);        // 使用半角的方式，性能比较好
//
//        Paint paint = new Paint();
//        paint.setAntiAlias(true);
//        paint.setColor(Color.BLUE);
//        int saveCount = canvas.saveLayer(0, 0, getWidth(), getHeight(), null, Canvas.ALL_SAVE_FLAG);
//        super.dispatchDraw(canvas);
//        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
//
//
//        canvas.drawPath(clipPath, paint);
//        canvas.restoreToCount(saveCount);
//        paint.setXfermode(null);

        super.onDraw(canvas);
    }

    @Override
     protected void dispatchDraw(Canvas canvas) {
        Path clipPath = new Path();
        clipPath.addRoundRect(new RectF(10, 10,   getMeasuredWidth(),   getMeasuredHeight()), 26,16, Path.Direction.CW);        // 使用半角的方式，性能比较好

           Paint paint = new Paint();
           paint.setAntiAlias(true);
            paint.setColor(Color.WHITE);
             int saveCount = canvas.saveLayer(0, 0, getWidth(), getHeight(), null, Canvas.ALL_SAVE_FLAG);
            super.dispatchDraw(canvas);
          paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.MULTIPLY));
            canvas.drawPath(clipPath, paint);
             canvas.restoreToCount(saveCount);
             paint.setXfermode(null);
         }

    @Override
    public void draw(Canvas canvas) {
        Bitmap offscreenBitmap = Bitmap.createBitmap(canvas.getWidth(), canvas.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas offscreenCanvas = new Canvas(offscreenBitmap);

        super.draw(offscreenCanvas);

        if (maskBitmap == null) {
            maskBitmap = createMask(canvas.getWidth(), canvas.getHeight());
        }

        offscreenCanvas.drawBitmap(maskBitmap, 0f, 0f, maskPaint);
        canvas.drawBitmap(offscreenBitmap, 0f, 0f, paint);
    }

    private Bitmap createMask(int width, int height) {
        Bitmap mask = Bitmap.createBitmap(width, height, Bitmap.Config.ALPHA_8);
        Canvas canvas = new Canvas(mask);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.WHITE);

        canvas.drawRect(0, 0, width, height, paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        canvas.drawRoundRect(new  RectF(0, 0, width, height), cornerRadius, cornerRadius, paint);

        return mask;
    }

    void initView(Context context){
        // i am not sure with these inflater lines
      LayoutInflater   inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        // you should not use a new instance of MyWebView here
        // MyWebView view = (MyWebView) inflater.inflate(R.layout.custom_webview, this);
        this.getSettings().setUseWideViewPort(true);
        this.getSettings().setLoadWithOverviewMode(true);

    }
}
